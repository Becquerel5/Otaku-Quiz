document.addEventListener('DOMContentLoaded', () => {
    let timerElement = document.getElementById('timer');
    let questionTextElement = document.getElementById('question-text');
    let choicesElement = document.getElementById('choices');
    let currentQuestionIndex = 0;
    let timeLeft = 30;
    let countdown;
    let showingAnswer = false;

    function loadQuestion(index) {
        if (index >= questions.length) {
            questionTextElement.textContent = "Quiz terminé!";
            choicesElement.innerHTML = "";
            timerElement.textContent = "";
            clearInterval(countdown);
            return;
        }

        const question = questions[index];
        questionTextElement.textContent = question.question_text;
        //questionTextElement.textContent = question.correct_answer;
        choicesElement.innerHTML = "";

        fetch(`get_choices.php?question_id=${question.id}`)
            .then(response => response.json())
            .then(choices => {
                choices.forEach(choice => {
                    let button = document.createElement('button');
                    button.textContent = choice.choice_text;
                    button.classList.add('choice');
                    button.dataset.correct = choice.choice_text === question.correct_answer;
                    button.addEventListener('click', () => {
                        // Placeholder for any click action needed
                    });
                    choicesElement.appendChild(button);
                });
            });

        timeLeft = 30;
        timerElement.textContent = timeLeft;
        showingAnswer = false;
    }

    function showCorrectAnswer() {
        const correctAnswer = questions[currentQuestionIndex].correct_answer;
        Array.from(choicesElement.children).forEach(button => {
            if (button.textContent === correctAnswer) {
                button.style.backgroundColor = 'green';
            } else {
                button.style.backgroundColor = 'red';
            }
        });
        showingAnswer = true;
    }

    function nextQuestion() {
        currentQuestionIndex++;
        loadQuestion(currentQuestionIndex);
    }

    function startCountdown() {
        countdown = setInterval(() => {
            if (timeLeft > 0 && !showingAnswer) {
                timeLeft--;
                timerElement.textContent = timeLeft;
            } else if (timeLeft === 0 && !showingAnswer) {
                showCorrectAnswer();
                timeLeft = 5; // Set time for showing the answer
            } else if (timeLeft > 0 && showingAnswer) {
                timeLeft--;
                timerElement.textContent = timeLeft;
            } else if (timeLeft === 0 && showingAnswer) {
                nextQuestion();
            }
        }, 1000);
    }

    loadQuestion(currentQuestionIndex);
    startCountdown();
});


/* function loadAnswer(index) {
    if (index >= questions.length) {
        return;
    }

    const question = questions[index];
    const correctAnswerText = question.correct_answer;

    // Clear the choices and show the correct answer
    choicesElement.innerHTML = "";
    const correctAnswerElement = document.createElement('div');
    correctAnswerElement.textContent = `Correct Answer: ${correctAnswerText}`;
    correctAnswerElement.classList.add('correct-answer');
    choicesElement.appendChild(correctAnswerElement);
} */